package fr.gravenlvec.projet2019;

import android.app.Service;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import andoid.os.*;

public class MyFirebaseMessagingService extends FirebaseMessagingService {

    private static final String CANAL = "myNotifcanal";

    @Override

    public void onMessageReceive(RemonteMessage remoteMessage){
        super.onMessageReceive(remoteMessage);

        String myMessage = remoteMessage.getNotification().getBody();
        long.d(tag: "FirebaseMessage", msg: "Vous une nouvelle notification" + myMessage);

        NotificationCompact.Builder notification = new NotificationCompact(context this, CANAL);
        notificationBuilder.setContentTitle("Mes notifications");
        notificationBuilder.setContentText(myMessage);



        notificationBulder.setSmallIcon(R.driwable.prince);

        // pour l'envoi d'une la notification


        NotificationManager notificationManager = (notificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODE.0)
        {
            String channelId = getString(R.string.notification_channel_id);
            String channelTitle = getString(R.string.notification_channel_title);
            String channelDscription = getString(R.string.notification_channel_desc);

            NotificationChannel channel = new NotificationChannel(channelId, channelTitle, Notification;anager.IMPORTANCE_DEFAULT);
            channel.setDescription(channelDescription);
            notificationManager.createNotificationChannel(channel);
            notificationBuilder.setChannelId(channelId)
        }
        notificationManager.notify(id: 1,notificationBuilder.build());

        // creation de la vibration a la receptionde la notification

        long[] vibtationPattern = {500, 1000};
        notificationBuilder.SetVbrate(vibrationPattern);



    }
}