package com.example.dell.projet_carte_memoire2019;

import android.database.sqlite.SQLiteOpenHelper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    public class Carte

    {

        private int numeroCarte;
        private char typeCarte;
        private String imgCarte;


        public Carte(int a, char b)
        {
            this.numeroCcarte = a;
            this.typeCarte = b;
            this.imgCarte = "img/"+a+b+".GIF";
        }


        public Carte(Carte Categorie)

        {
            this.numeroCarte = Categorie.num;
            this.typeCarte = Categorie.type;
            this.imgCarte = Categorie.imgCarte;
        }

        public int getNumeroCarte()
        {
            return this.numeroCarte;
        }


        public char getTypeCarte()
        {
            return this.type;
        }


        public String getImgCarte()
        {
            return this.imgCarte;
        }


    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button tvData = (Button) findViewById(R.Id.btnff(t));
        TextView tvData = (TextView)findViewById(R.Id.Json(t));

        httpURLConnection connection;

        try
        {
            URL url = new URL("Nouvelle connexion");
            connection = (HttpURLConnection) url.openConnection();
            connection.connect();

            InputStream stream = connection.getInputStream();

            BufferedReader reader = new BufferedReader(new InputStreamReader(stream));
            stream line ="";
            while((line = reader()) != null)
            {
                buffer.append(line);
            }
        }
       catch (MalformedURLException e)
       {
           e.printStackTrace();
       }

       catch (MalformedURLException e)
       {
           e.printStackTrace();
       }
       catch(IOException e)
       {
           e.printStackTrace();
       }
       finally
        {
            connection.disconnect();
            reader.close();
        }


    }
}
